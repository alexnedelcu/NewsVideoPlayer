package com.alexnedelcu.videoplayer.search;

public abstract class Command {
	public abstract void execute(NewsArticleManager mgr);
}
